
Anna Breck (breck061)
    I tried working with a partner but they didnt contribute at either of our 
    meetings about the project and i dont know their x500

    TO COMPILE: javac FractalDrawer.java
                java FractalDrawer

    ADDITIONAL FEATURES: I used java.Random to get my colors and java.lang.math to get the sqrt needed for the triangle perimeter
    
    BUGS: Just the known Canvas.java bug that causes the fractals to not show unless the window is resized

    SCOURCES: https://docs.oracle.com/ for info on java random

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.
Anna Breck

